
import logging
import sqlite3
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
from datetime import datetime
from persiantools.jdatetime import JalaliDate

# تنظیمات لاگ
logging.basicConfig(level=logging.INFO)

# اتصال به دیتابیس SQLite
conn = sqlite3.connect("transactions.db", check_same_thread=False)
cursor = conn.cursor()

# ایجاد جدول کاربران و تراکنش‌ها
cursor.execute("""
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT,
    is_admin INTEGER DEFAULT 0
)
""")
cursor.execute("""
CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user TEXT,
    type TEXT,
    from_card TEXT,
    to_card TEXT,
    card TEXT,
    amount INTEGER,
    reason TEXT,
    date TEXT
)
""")
conn.commit()

# کاربران لاگین‌شده
logged_in_users = {}

# تبدیل تاریخ میلادی به شمسی
def miladi_to_shamsi(dt_str):
    dt = datetime.strptime(dt_str, "%Y-%m-%d %H:%M:%S.%f")
    return JalaliDate(dt).strftime('%Y/%m/%d')

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("سلام! برای ورود از /login username password استفاده کن.")

async def login(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        username, password = context.args
        cursor.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password))
        user = cursor.fetchone()
        if user:
            logged_in_users[update.effective_user.id] = username
            await update.message.reply_text(f"خوش آمدی {username}!")
        else:
            await update.message.reply_text("یوزرنیم یا رمز اشتباهه.")
    except:
        await update.message.reply_text("فرمت: /login username password")

async def add_payment(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if uid not in logged_in_users:
        await update.message.reply_text("اول باید وارد شوی.")
        return
    username = logged_in_users[uid]
    try:
        from_card, to_card, amount, *reason = context.args
        cursor.execute("""
            INSERT INTO transactions (user, type, from_card, to_card, amount, reason, date)
            VALUES (?, 'payment', ?, ?, ?, ?, ?)
        """, (username, from_card, to_card, int(amount), " ".join(reason), str(datetime.now())))
        conn.commit()
        await update.message.reply_text("واریزی ثبت شد.")
    except:
        await update.message.reply_text("فرمت: /add_payment from_card to_card amount reason")

async def add_cost(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if uid not in logged_in_users:
        await update.message.reply_text("اول باید وارد شوی.")
        return
    username = logged_in_users[uid]
    try:
        card, amount, *reason = context.args
        cursor.execute("""
            INSERT INTO transactions (user, type, card, amount, reason, date)
            VALUES (?, 'cost', ?, ?, ?, ?)
        """, (username, card, int(amount), " ".join(reason), str(datetime.now())))
        conn.commit()
        await update.message.reply_text("هزینه ثبت شد.")
    except:
        await update.message.reply_text("فرمت: /add_cost card amount reason")

async def report(update: Update, context: ContextTypes.DEFAULT_TYPE):
    cursor.execute("SELECT * FROM transactions")
    rows = cursor.fetchall()
    if not rows:
        await update.message.reply_text("هیچ تراکنشی ثبت نشده.")
        return
    text = ""
    for r in rows:
        if r[2] == "payment":
            text += f"[{r[0]}] واریز {r[6]} از {r[3]} به {r[4]} بابت {r[7]} - {miladi_to_shamsi(r[8])}\n"
        elif r[2] == "cost":
            text += f"[{r[0]}] هزینه {r[6]} از کارت {r[5]} بابت {r[7]} - {miladi_to_shamsi(r[8])}\n"
    await update.message.reply_text(text)

async def delete(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if uid not in logged_in_users:
        await update.message.reply_text("اول وارد شو.")
        return
    try:
        id_to_delete = int(context.args[0])
        cursor.execute("DELETE FROM transactions WHERE id=?", (id_to_delete,))
        conn.commit()
        await update.message.reply_text(f"تراکنش شماره {id_to_delete} حذف شد.")
    except:
        await update.message.reply_text("فرمت: /delete id")

async def report_from(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        shamsi_date = context.args[0]
        parts = list(map(int, shamsi_date.split("-")))
        miladi_date = str(JalaliDate(parts[0], parts[1], parts[2]).to_gregorian())
        cursor.execute("SELECT * FROM transactions WHERE date >= ?", (miladi_date,))
        rows = cursor.fetchall()
        if not rows:
            await update.message.reply_text("هیچ تراکنشی از این تاریخ به بعد ثبت نشده.")
            return
        text = ""
        for r in rows:
            if r[2] == "payment":
                text += f"[{r[0]}] واریز {r[6]} از {r[3]} به {r[4]} بابت {r[7]} - {miladi_to_shamsi(r[8])}\n"
            elif r[2] == "cost":
                text += f"[{r[0]}] هزینه {r[6]} از کارت {r[5]} بابت {r[7]} - {miladi_to_shamsi(r[8])}\n"
        await update.message.reply_text(text)
    except:
        await update.message.reply_text("فرمت صحیح: /report_from 1403-03-01")

def main():
    app = ApplicationBuilder().token("YOUR_BOT_TOKEN").build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("login", login))
    app.add_handler(CommandHandler("add_payment", add_payment))
    app.add_handler(CommandHandler("add_cost", add_cost))
    app.add_handler(CommandHandler("report", report))
    app.add_handler(CommandHandler("delete", delete))
    app.add_handler(CommandHandler("report_from", report_from))
    app.run_polling()

if __name__ == "__main__":
    main()
